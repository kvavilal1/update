package com.capgemini.controller;


import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.capgemini.model.Category;
import com.capgemini.model.Customer;
import com.capgemini.model.Merchant;
import com.capgemini.model.Product;
import com.capgemini.model.PromoCode;


@Controller
public class JspController {
//	@RequestMapping(value="/Inventory")
//	public String consumeQuote1(){
//		return "Inventory";
//	}
	
	@RequestMapping(value="/")
	public String consumeQuote(){
		return "index";
	}
	
	@RequestMapping("/index")
	public String consume(){
		return "index";
	}
	/*
	@RequestMapping(value="/MerchantDetails")
	public String consumeQuote2(){
		return "MerchantDetails";
	}
		
	@RequestMapping(value="/CustomerDetails")
	public String consumeQuote3(){
		return "CustomerDetails";
	}
	
	@RequestMapping(value="/AcceptMReq")
	public String consumeQuote12(){
		return "AcceptMReq";
	}*/
	
	@RequestMapping(value="/AddPromo")
	public String consumeQuote8(ModelMap model){
		RestTemplate restTemplate = new RestTemplate();
		PromoCode[] message = restTemplate.getForObject("http://localhost:9890/promo.json",PromoCode[].class);
		List<PromoCode> list=Arrays.asList(message);
		model.put("promos",list);
		return "AddPromo";
	}
	@RequestMapping(value="/ProductRequest")
	public String consumeQuote7(ModelMap model){
		RestTemplate restTemplate = new RestTemplate();
		Product[] message = restTemplate.getForObject("http://localhost:9890/prodet.json",Product[].class);
		List<Product> list=Arrays.asList(message);
		model.put("prore",list);	
		return "ProductRequest";
	}
	@RequestMapping(value="/MerchantResult")
	public String consumeQuote11(ModelMap model){
		RestTemplate restTemplate = new RestTemplate();
		Product[] message = restTemplate.getForObject("http://localhost:9890/prodet.json",Product[].class);
		List<Product> list=Arrays.asList(message);
		model.put("mercs",list);		
		return "MerchantResult";
	}
	@RequestMapping(value="/CategoryResult")
	public String consumeQuote10(ModelMap model){
		RestTemplate restTemplate = new RestTemplate();
		Category[] message = restTemplate.getForObject("http://localhost:9890/cat.json",Category[].class);
		List<Category> cato=Arrays.asList(message);
		model.put("cats",cato);
		return "CategoryResult";
	}
	@RequestMapping(value="/ProductResult")
	public String consumeQuote9(ModelMap model){
		RestTemplate restTemplate = new RestTemplate();
		Product[] message = restTemplate.getForObject("http://localhost:9890/prodet.json",Product[].class);
		List<Product> list=Arrays.asList(message);
		model.put("prods",list);
		return "ProductResult";
	}
	@RequestMapping(value="/MerchantRequest")
	public String consumeQuote6(ModelMap model){
		RestTemplate restTemplate = new RestTemplate();
		Merchant[] message = restTemplate.getForObject("http://localhost:9890/mer.json", Merchant[].class);
		List<Merchant> list=Arrays.asList(message);
		model.put("mers",list);
		System.out.println(list);
		return "MerchantRequest";
	}
	@RequestMapping(value="/GenerateReports")
	public String consumeQuote5(){
		return "GenerateReports";
	}
	@RequestMapping(value="/ViewDetails")
	public String consumeQuote13(@RequestParam("id") int id, ModelMap model){
		System.out.println("id in view details"+id);
		RestTemplate restTemplate = new RestTemplate();
		Product[] message = restTemplate.getForObject("http://localhost:9890/prodet.json",Product[].class);
		List<Product> list=Arrays.asList(message);
		model.put("details",list);
		System.out.println(list);
		
		return "ViewDetails";
	}
	@RequestMapping(value="/ProductStatus")
	public String consumeQuote4(ModelMap model){
		RestTemplate restTemplate = new RestTemplate();
		Product[] message = restTemplate.getForObject("http://localhost:9890/prodet.json",Product[].class);
		List<Product> list=Arrays.asList(message);
		model.put("prods",list);
		return "ProductStatus";
	}
	@RequestMapping(value="/CustomerDetails")
	public    String  consumeMessage(ModelMap model){
		RestTemplate restTemplate = new RestTemplate();
		Customer[] message = restTemplate.getForObject("http://localhost:9890/customer.json", Customer[].class);
		List<Customer> customer=Arrays.asList(message);
		model.put("customer",customer);
		System.out.println(customer);
		return "CustomerDetails";
	}
	@RequestMapping(value="/MerchantDetails")
	public String consumeQuote2(ModelMap model){
		RestTemplate restTemplate = new RestTemplate();
		Merchant[] message = restTemplate.getForObject("http://localhost:9890/customer.json", Merchant[].class);
		List<Merchant> list=Arrays.asList(message);
		model.put("merchants",list);
		System.out.println(list);
		return "MerchantDetails";
	}
	@RequestMapping(value="/Inventory")
	public    String  consumeMessage1(ModelMap model){
		RestTemplate restTemplate = new RestTemplate();
		Product[] message = restTemplate.getForObject("http://localhost:9890/inv.json", Product[].class);
		List<Product> list=Arrays.asList(message);
		model.put("products",list);
		System.out.println(list);
		return "Inventory";
	}
	/*@RequestMapping(value="/welcome")
	public String showWelcomePage(Integer id, ModelMap model){
		
		RestTemplate restTemplate = new RestTemplate();
		Message message = restTemplate.getForObject("http://localhost:9090/getmessage?id="+id, Message.class);
		System.out.println(message);
		model.put("message", message);
		return "welcome";
	}Product[] editProduct= restTemplate.getForObject("http://localhost:9899/addProduct.json",Product[].class);
		List<Product> products=Arrays.asList(editProduct);
		model.put("product",products);*/
}
